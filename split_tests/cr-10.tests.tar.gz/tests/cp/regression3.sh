#!/bin/sh
# ensure that cp's --no-preserve=mode works correctly

# Copyright (C) 2002-2012 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src
print_ver_ cp

rm -rf a
mkdir a
touch a/a
cd a
cp -rfT --preserve=timestamps --no-preserve=mode,ownership a b || fail=1
#mode_d1=$(ls -l a | gawk '{print $1}')
#mode_d3=$(ls -l b | gawk '{print $1}')

cd - > /dev/null
rm -rf a


Exit $fail
