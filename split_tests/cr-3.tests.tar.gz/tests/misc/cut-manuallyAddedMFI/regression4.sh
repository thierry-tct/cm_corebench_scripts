#!/bin/sh
# Ensure that cut does not allocate mem for large ranges

# Copyright (C) 2012-2013 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src
print_ver_ cut
require_ulimit_v_
getlimits_


# Ensure ranges are merged correctly when large range logic is in effect
echo 3 > exp
(dd bs=1MB if=/dev/zero count=1; echo '323') |
  cut -n -b1-1000000,2-3,4-5,1000001 2>>err | tail -c2 > out || fail=1
compare exp out || fail=1

compare /dev/null err || fail=1

Exit $fail
